// to make the question tag display display what we should do 



 
function opening(){
    let questionWindow = document.getElementById('question-popup');
let open = document.getElementById('open-key').click();
questionWindow.style.display = 'block';


}

function closing() {
    let questionWindow = document.getElementById('question-popup');
     let close = document.getElementById('close-key').click();
    questionWindow.style.display ='none';
}

